# Israeli Labor Laws Summary

Quick-reference table of key Israeli labor laws governing employee rights.

## Core Employment Laws

| Law | Hebrew Name | Year | Key Provisions |
|-----|-------------|------|----------------|
| Annual Leave Law | חוק חופשה שנתית | 1951 | Minimum paid vacation days based on seniority (12-28 days). Vacation pay and pidyon (payout) rules |
| Sick Pay Law | חוק דמי מחלה | 1976 | 1.5 sick days per month. Graduated pay: 0% day 1, 50% days 2-3, 100% day 4+. Maximum 90-day accumulation |
| Hours of Work and Rest Law | חוק שעות עבודה ומנוחה | 1951 | 8-hour workday, 42-hour week. Overtime: 125% first 2 hours, 150% after. Weekly rest of 36 hours. On the weekly rest day the premiums stack: 150% for ordinary hours, 175% for the first 2 overtime hours, 200% beyond that |
| Severance Pay Law | חוק פיצויי פיטורים | 1963 | One month salary per year after 1+ year. Section 14 pension fund arrangement. 15-day payment deadline |
| Employment of Women Law | חוק עבודת נשים | 1954 | 26-week maternity leave (15 weeks paid via Bituach Leumi). Termination protections for pregnant employees |
| Minimum Wage Law | חוק שכר מינימום | 1987 | Monthly minimum wage updated every April. As of 1 April 2026: NIS 6,443.85/month full-time, NIS 35.40/hour. Verify the current rate annually |
| Prior Notice of Termination and Resignation Law | חוק הודעה מוקדמת לפיטורים ולהתפטרות | 2001 | Notice period requirements based on employment duration |
| Wage Protection Law | חוק הגנת השכר | 1958 | Employer must provide a detailed pay slip (tlush) each period (s.24); wage payment deadlines and penalty interest for late wages |
| Sexual Harassment Prevention Law | חוק למניעת הטרדה מינית | 1998 | Employer obligations for prevention policy. Complaint procedures. Protection from retaliation |
| Equal Rights for People with Disabilities Law | חוק שוויון זכויות לאנשים עם מוגבלויות | 1998 | Reasonable accommodations. Non-discrimination in hiring, promotion, termination. Workplace accessibility |
| Equal Pay Law | חוק שכר שווה לעובדת ולעובד | 1996 | Equal pay for substantially equal work regardless of gender |
| Protection of Workers (Exposure of Offenses) Law | חוק הגנה על עובדים (חשיפת עבירות) | 1997 | Whistleblower protections for employees who report violations |
| Male and Female Workers (Equal Retirement Age) Law | חוק גיל פרישה | 2004 | Retirement age is 67 for men. For women it has been rising in stages since 2022 under an amendment to the Retirement Age Law, so it depends on date of birth: look up the woman's birth cohort rather than quoting a single figure |

## Pension and Savings

| Regulation | Hebrew Name | Year | Key Provisions |
|------------|-------------|------|----------------|
| Mandatory Pension Extension Order | צו הרחבה לפנסיה חובה | 2008 | 6% employee + 6.5% employer pension contributions + 6% employer severance (total 18.5% minimum). 8.33% severance is not the statutory floor: it is the rate that fully funds the statutory severance and is required for a full Section 14 release. Applies from day 1 for employees with prior pension, after 6 months (retroactive to day 1) for new pension holders |
| Convalescence Pay Extension Order | צו הרחבה דמי הבראה | Various | 5-10 convalescence days by seniority. 2026 rate: NIS 451.5/day private sector (raised from 418 by the extension order of 18.08.2026), NIS 511.6/day public sector. Reservist-support 1-day deduction applies in 2025-2026 |
| Section 45a, Income Tax Ordinance | סעיף 45א לפקודת מס הכנסה | Ongoing | 35% income-tax credit on the employee's pension contribution up to 7% of salary (approx. NIS 8,148/year ceiling in 2026). Applied automatically in payroll |

## Collective Labor Relations

| Law | Hebrew Name | Year | Key Provisions |
|-----|-------------|------|----------------|
| Collective Agreements Law | חוק הסכמים קיבוציים | 1957 | Framework for collective bargaining agreements between employers and unions |
| Settlement of Labor Disputes Law | חוק יישוב סכסוכי עבודה | 1957 | Strike and lockout procedures. Mediation and arbitration mechanisms |
| Labor Courts Law | חוק בית הדין לעבודה | 1969 | Jurisdiction of labor courts. Appeals process |

## Key Enforcement Bodies

| Body | Hebrew Name | Jurisdiction |
|------|-------------|-------------|
| Ministry of Labor | משרד העבודה | Enforcement of labor laws, work permits, termination permits for protected employees |
| Labor Court (Regional) | בית דין אזורי לעבודה | First instance for employment disputes |
| National Labor Court | בית הדין הארצי לעבודה | Appeals from regional labor courts |
| Equal Employment Opportunities Commission | נציבות שוויון הזדמנויות בעבודה | Discrimination and harassment complaints |
| Histadrut | ההסתדרות הכללית | National labor union, collective bargaining |

## Important Notes

- All laws set **minimum** standards. Collective agreements (heskemim kibbutziyim) and individual contracts can only improve upon these minimums
- Extension orders (tzavei harchava) apply specific collective agreement provisions to entire sectors
- The Labor Court has exclusive jurisdiction over most employment disputes
- Statute of limitations for wage claims: 7 years. For other employment claims: varies by law
- Many Israeli workers are covered by sector-specific collective agreements that provide benefits above the legal minimum

## Paternity leave and the second parent (detail)

**Paternity leave / second parent (the parent who did not give birth):**
- Absence right around the birth: up to 5 calendar days right after the birth (plus the day of birth itself), with no need for employer consent. The first 3 days are taken from the annual vacation balance (or unpaid if the balance is insufficient); the 4th and 5th days are treated as paid sick days
- Separately, a concurrent paternity-leave week: the second parent may take one week of the Birth and Parenting Period at the same time as the parent who gave birth, and receive a birth allowance for that week from Bituach Leumi (subject to its eligibility conditions)
- Taken together, the second parent can typically be home for about 7 paid days in the first month after the birth
- The second parent can also take a longer share of the Birth and Parenting Period (transferred from the other parent) after that parent has used at least 6 weeks

## Additional protections (detail)

**Additional protections:**
- Fertility treatments: employees undergoing fertility treatments receive absences as sick days and are protected from termination during treatment
- Adoption: similar leave entitlements apply to adoptive parents
- Nursing mothers: entitled to a reduced work day (1 hour less) for 4 months after returning from maternity leave, with full pay
